package domain;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

/**
 * Implementación de la capa de dominio del juego POOBCHIS
 * Andres Camilo Oñate Quimbayo, Nicolas Ariza Barbosa
 * ECI POOB 2022-1
 */
public class Board implements Serializable {
	public static final int numWhiteSquares = 68;
	private int numPlayers;
	private int pawnsInGame;
	private HashMap<Color,Square> houses = new HashMap<Color,Square>() ;
	private ArrayList<Square> squares = new ArrayList<Square>();
	private HashMap<Color,ArrayList<Square>> arrivals = new HashMap<Color,ArrayList<Square>>();
	private ArrayList<Color> colors = new ArrayList<Color> (Arrays.asList(Color.YELLOW,Color.BLUE,Color.RED,Color.GREEN));
	private ArrayList<String> pawnTypes= new ArrayList<String> (Arrays.asList("AdvantageousPawn","EngineerPawn", "JumpingPawn", "RocketPawn", "VacuumPawn"));

	/**
	 * Class constructor
	 */
	public Board(int numPlayers){
		this.numPlayers = numPlayers;
		this.pawnsInGame = 0;
		initializeBoard();
	}

	/**
	 * Initialize the board
	 */
	public void initializeBoard() {
		initializeWhiteSquares();
	}

	/**
	 * Initialize player arrivals
	 * @param color Color of the player associated with arrival.
	 */
	public void initializeHalls (Color color){
		int cont = 0;
		ArrayList<Square> HallSquare = new ArrayList<Square>();
		for (int j = 0; j < 8; j++){
			if (j == 7){
				HallSquare.add(new Arrival(color, cont));
			}else{
				HallSquare.add(new Square(color, "Normal", cont));
			}
			cont++;
		}
		arrivals.put(color, HallSquare);
	}

	/**
	 * Initialize the main Squares
	 * The main squares have indices ranging from 0 to 67
	 */
	private void initializeWhiteSquares() {
		int cont = 0;
		for (Color color : this.colors) {
			for (int j = 0; j < 17; j++) {
				if (j == 5) {
					squares.add(new Start(color, cont));
				} else if (j == 0 || j == 12) {
					squares.add(new Safe(Color.GRAY, cont));
				} else {
					squares.add(new Square(Color.WHITE, "Normal", cont));
				}
				cont++;
			}
		}
        //setSquare(new AdvanceWildCard(new Color(230, 76, 14),9),9);
	}

	/**
	 * Initialize the houses of a specific player
	 * Add each player their pawns
	 * @param player Player
	 */
	public void initializeHomePlayer(Player player){
		Color color = player.getColor();
		Home home = new Home(color, 0);
		HashMap<Integer,Pawn> initialPawns = new HashMap<Integer,Pawn>();

		VacuumPawn powerPawn =  new VacuumPawn(color,0,1,home);
		initialPawns.put(0,powerPawn);
		home.addPawn(powerPawn);
		for (int k = 1; k < 4; k++ ){
			Pawn pawn = new Pawn("Normal",color, k, 1, home);
			initialPawns.put(k,pawn);
			home.addPawn(pawn);
		}

		player.setPawns(initialPawns);
		initializeStartPLayer(player);
		houses.put(color,home);
	}

	/**
	 * Initializes the starting position of each player that is as an attribute
	 * @param player Player to initialize
	 */
	public void initializeStartPLayer(Player player){
		Color color = player.getColor();
		if (color.equals(Color.YELLOW)){
			player.setStart(5);
		}else if(color.equals(Color.BLUE)){
			player.setStart(22);
		}else if(color.equals(Color.RED)){
			player.setStart(39);
		}else if(color.equals(Color.GREEN)){
			player.setStart(56);
		}
	}

	/**
	 * Move a token to its respective start.
	 * @param player Player
	 */
	public void moveToStart(Player player) throws POOBChisException{
		Color color = player.getColor();
		Pawn toMove = player.getPawnInHome();
		Square start = squares.get(player.getStart());
		if(!start.haveSpace()) throw new POOBChisException(POOBChisException.SQUARE_FILLED);
		houses.get(color).delPawn(toMove);
		player.addPawnsInGame();
		start.addPawn(toMove);
		toMove.setInGame(true);
		toMove.setActualSquare(start);
	}

	/**
	 * Move a player token
	 * Validate its position to determine how it should move.
	 * @param  pawn Pawn to Move
	 * @param  player Pawn Color
	 * @param  dice value of a dice
	 */
	public void move(int pawn, Player player, int dice) throws POOBChisException{
		Pawn movePawn = player.getPawn(pawn);
		if(!movePawn.isInGame()) throw new POOBChisException(POOBChisException.PAWN_NOT_INGAME);
		int index = movePawn.getActualSquare().getNumber();
		int finalIndex = index + dice;
		if (!movePawn.isArriving() && finalIndex != numWhiteSquares) {
			index += dice;
			moveIntoWhite(movePawn, index, dice, player);
		}else if (finalIndex == numWhiteSquares){
			squares.get(index).delPawn(movePawn);
			index = 0;
			Square square = squares.get(index);
			if(!square.haveSpace()) throw new POOBChisException(POOBChisException.SQUARE_FILLED);
			square.addPawn(movePawn);
			movePawn.setActualSquare(square);
			movePawn.subtractSquares(dice);
		}else{
			moveIntoHall(movePawn,dice, player);
		}
		if(movePawn instanceof EngineerPawn) ((EngineerPawn) movePawn).activatePower(squares);
	}

	/**
	 * Move a player token
	 * Validate its position to determine how it should move.
	 * @param  pawn Pawn to Move
	 * @param index Final Square index
	 * @param  player Pawn Color
	 * @param  dice value of a dice
	 */
	public void moveIntoWhite(Pawn pawn, int index, int dice, Player player) throws POOBChisException{
		if(pawn.getSquaresToHome() < 1){
			passToHall(pawn, player);
		}else if(index > numWhiteSquares && pawn.getSquaresToHome() > 0){
			crossBoard(index,pawn,player);
		}else{
			moveNormal(index,pawn,player);
		}
		pawn.subtractSquares(dice);
		player.setLastPawnMove(pawn);

	}

	/**
	 * Move a player token
	 * Validate its position to determine how it should move.
	 * Since the board is closed, the board must pass from one index to another.
	 * @param index Final Square index
	 * @param  pawn Pawn to Move
	 * @param  player Pawn Color
	 */
	public void crossBoard(int index, Pawn pawn, Player player) throws POOBChisException{
		if(!lockFree(pawn.getActualSquare().getNumber(),numWhiteSquares)) throw new POOBChisException(POOBChisException.SQUARE_BLOCK);
		squares.get(pawn.getActualSquare().getNumber()).delPawn(pawn);
		index = index - numWhiteSquares;
		if(!lockFree(0,index)) throw new POOBChisException(POOBChisException.SQUARE_BLOCK);
		Square square = squares.get(index);
		if(!square.haveSpace()) throw new POOBChisException(POOBChisException.SQUARE_FILLED);
		square.addPawn(pawn);
		pawn.setActualSquare(square);
		if (square.colorPawnsDifferent(pawn.getColor()))pawnEats(index,player);
		if (square instanceof WildCard) activateWildCard(square,pawn,player);
	}
	/**
	 * Move a player token
	 * Validate its position to determine how it should move.
	 * Movement without conditions, it moves in the 68 squares.
	 * @param index Final Square index
	 * @param  pawn Pawn to Move
	 * @param  player Pawn Color
	 */
	public void moveNormal(int index,Pawn pawn, Player player) throws POOBChisException{
		if(!lockFree(pawn.getActualSquare().getNumber(),index)) throw new POOBChisException(POOBChisException.SQUARE_BLOCK);
		squares.get(pawn.getActualSquare().getNumber()).delPawn(pawn);
		Square square = squares.get(index);
		if(!square.haveSpace()) throw new POOBChisException(POOBChisException.SQUARE_FILLED);
		square.addPawn(pawn);
		if (square.colorPawnsDifferent(pawn.getColor()) && !(square instanceof Safe)){
			pawnEats(index,player);
		}
		pawn.setActualSquare(square);
		if (square instanceof WildCard) activateWildCard(square,pawn, player);
	}

	/**
	 * A pawn arrives at a square where there is one of another color.
	 * It is validated that he is not immortal
	 * @param  index index of the square
	 */
	public void pawnEats(int index, Player player){
		Square square = squares.get(index);
        if(!(square instanceof Safe)){
			Pawn pawn = square.eat();
			if(!pawn.isImmortal()){
				Color color = pawn.getColor();
				pawn.setInGame(false);
				pawn.setActualSquare(houses.get(color));
				houses.get(color).addPawn(pawn);
			}
		}
	}

	/**
	 * Move a player token
	 * The pawn enters upon final squares
	 * @param  pawn Pawn to Move
	 * @param  player Pawn Color
	 */
	public void passToHall(Pawn pawn, Player player){
		squares.get(pawn.getActualSquare().getNumber()).delPawn(pawn);
		Color color = player.getColor();
		int index = (-1) * pawn.getSquaresToHome() - 1;
		if(index == -1) index = 0;
		pawn.setSquaresToHome(7-index);
		pawn.setArriving(true);
		pawn.setActualSquare(arrivals.get(color).get(index));
		arrivals.get(color).get(index).addPawn(pawn);
	}

	/**
	 * Move a player token
	 * The pawn move upon final squares
	 * @param  pawn Pawn to Move
	 * @param  dice Dice Value
	 * @param player
	 */
	public void moveIntoHall(Pawn pawn, int dice ,Player player) throws POOBChisException{
		Color color = pawn.getColor();
		int index =  pawn.getActualSquare().getNumber();
		Square square = arrivals.get(color).get(index);
		if(!square.haveSpace()) throw new POOBChisException(POOBChisException.SQUARE_FILLED);
		pawn.subtractSquares(dice);
		square.delPawn(pawn);
		index += dice;
		square = arrivals.get(color).get(index);
		square.addPawn(pawn);
		pawn.setActualSquare(square);
		if( square instanceof Arrival) {
			pawn.setInGame(false);
			player.addPawnsInArrival();
		}
	}



	/**
	 * Get the squares of the board
	 * @return squares
	 */
	public ArrayList<Square> getSquares(){
		return  this.squares;
	}

	/**
	 * Returns the number of pawns in game
	 * @return pawns
	 */
	public int getPawnsInBoard(){
		int cont = 0;
		for(Square square: this.squares){
			cont += square.getNumPawns();
		}
		return cont;
	}

    /**
     * Returns the number of pawns in the arrival
     * @return pawns in arrival
     */
	public int getPawnsInArrivals(Color color){
		int size = arrivals.get(color).size();
		int cont = 0;
		for (int i = 0; i< size; i++){
			cont += arrivals.get(color).get(i).getNumPawns();
		}
		return cont;
	}

	/**
	 * Sets if the game is over
	 * @return state
	 */
	public boolean finish(){
		return false;
	}

    /**
     * executes the actions corresponding to having three times double dice
     * @param player Player
     */
	public void threeDiceRule(Player player){
		Color color = player.getColor();
		Pawn pawn = player.getLastPawnMove();
		if(pawn != null){
			pawn.getActualSquare().delPawn(pawn);
			pawn.setActualSquare(houses.get(color));
			houses.get(color).addPawn(pawn);
			player.decreasePawnsInGame();
		}
	}

	/**
	 * Validate a set of pawns according to the rules of parchis.
	 * @param pawns
	 * @param dice
	 */
	public ArrayList<Pawn> validatePawns(ArrayList<Pawn> pawns, int dice) {
		ArrayList<Pawn> validate = new ArrayList<Pawn>();
		for (Pawn pawn : pawns) {
			int index = pawn.getActualSquare().getNumber();
			int dIndex = index + dice;
			if(validatePawn(pawn, index,dIndex)) validate.add(pawn);
		}
		return validate;
	}

	/**
	 * Validate a pawn according to the rules of parchis.
	 * @param pawn
	 * @param indexA
	 * @param indexB
	 */
	public boolean validatePawn(Pawn pawn, int indexA, int indexB){
		boolean flag = false;
		if (pawn.isInGame() && !pawn.isArriving() && !(pawn instanceof JumpingPawn)) {
			if (lockFree(indexA, indexB)){
				flag = true;
			}
		}else if(pawn.isArriving() && (indexB < 8)){
			flag = true;
		}
		return flag;
	}

	/**
	 * It checks if there is a lock in a certain range of the board.
	 * @param indexA initial Square
	 * @param indexB end Square
	 */
	public boolean lockFree(int indexA, int indexB){
		boolean flag = true;
		for(int i = indexA+1; i < indexB; i++){
			if(squares.get(i).isBarrier()){
				flag = false;
			}
		}
		return flag;
	}

	/**
	 * Get a square on the board
	 * @param index index of the square
	 */
    public Square getSquare(int index){
        return this.squares.get(index);
    }

	/**
	 * Set a square on the board
	 * @param newSquare new square to update
	 * @param index index of the square
	 */
    public void setSquare(Square newSquare, int index){
        Square square = this.getSquare(index);
        ArrayList<Pawn> pawns = square.getPawns();
        newSquare.setPawns(pawns);
        this.squares.set(index,newSquare);
    }

	/**
	 * Gets a pawn type from the pawn catalog
	 * @return pawnType
	 */
	public String choiseRandomPawnName(){
		Random random = new Random();
		int index = random.nextInt(5);
		return this.pawnTypes.get(index);
	}

	/**
	 * Method that activates the abilities of wild cards on the board.
	 * @param square WildCard Square
	 * @param pawn  pawn in square
	 * @param  player current Player
	 */
	public void activateWildCard(Square square, Pawn pawn, Player player) throws POOBChisException{
		int index = square.getNumber();
		if(square instanceof AdvanceWildCard){
			if(validatePawn(pawn,index,index+5)){
				move(pawn.getNumber(),player,5);
			}
		}else if(square instanceof BackWildCard){
			if(validatePawn(pawn,index-5,index) && ((BackWildCard) square).validateMove(player,index-5)){
				move(pawn.getNumber(),player,-5);
			}
		}else if (square instanceof JailWildCard){
			pawnEats(index,player);
		}else if(square instanceof OutJailWildCard){
			if(player.numPawnsInHome() > 0){
				moveToStart(player);
			}
		}else if(square instanceof MutateWildCard) {
			String type = choiseRandomPawnName();
			Pawn newPawn = ((MutateWildCard) square).mutatePawn(type);
			int number = newPawn.getNumber();
			player.setPawn(number,newPawn);
		}
	}

}