package domain;

import java.awt.*;

public class JailWildCard extends WildCard{

    /**
     * Class constructor
     */
    public JailWildCard(Color color, int number){
        super(color, "Jail", number);
        this.color = Color.BLACK;
    }

}
