package domain;

import java.awt.*;

public class OutJailWildCard extends WildCard{

    /**
     * Class constructor
     */
    public OutJailWildCard (Color color, int number){
        super(color, "OutJail", number);
    }
}
