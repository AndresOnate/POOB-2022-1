package domain;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class Player implements Serializable {

    private int numPawns = 4; //Posible extensión
    private Color color;
    private int turn;
    private int PawnsInGame;
    private int equalDiceNum;
    private HashMap<Integer,Pawn> pawns = new HashMap<Integer,Pawn>();
    private Pawn lastPawnMove;
    private int pawnsInArrival;
    private int start;

    /**
     * Class constructor
     */
    public Player(Color color){
        this.color = color;
        this.PawnsInGame = 0;
        this.equalDiceNum = 0;
        this.pawnsInArrival = 0;
        this.turn = 0;
    }

    /**
     * Get the number of pawns in play for a player
     */
    public  int getPawnsInGame(){
        return  this.PawnsInGame;
    }

    /**
     * Updates the player's number of pawns in play
     * @param PawnsInGame new pawns in game
     */
    public void setPawnsInGame(int PawnsInGame){
        this.PawnsInGame = PawnsInGame;
    }

    /**
     * Get player color
     * @return  color player
     */
    public Color getColor(){
        return  this.color;
    }

    /**
     * Gets a certain token from a player
     * @param index of the pawn (The player has four pawns)
     * @return  Pawn
     */
    public Pawn getPawn(int index){
        return this.pawns.get(index);
    }

    /**
     * Update player tokens
     * @param paws new pawns
     */
    public void setPawns(HashMap<Integer,Pawn> paws){
        this.pawns = paws;
    }

    /**
     * Increases the number of pawns in play for a player.
     */
    public void addPawnsInGame(){
        this.PawnsInGame ++;
    }

    /**
     * Decreases the number of pawns in play for a player.
     */
    public void decreasePawnsInGame(){
        this.PawnsInGame --;
    }

    /**
     * Determines if a player has pawns at home
     * @return  Player has pawns at home
     */
    public boolean havePawnsInHome(){
        for (int i = 0; i < this.numPawns; i++){
            if(!this.pawns.get(i).isInGame()){
                return true;
            }
        }
        return false;
    }

    /**
     * Determines the num of pawns in home
     * @return  Player num pawns at home
     */
    public int numPawnsInHome(){
        int count = 0;
        for (int i = 0; i < this.numPawns; i++){
            if(!this.pawns.get(i).isInGame()){
                count++;
            }
        }
        return count;
    }

    /**
     * Get a token that is in the player's house.
     * @return  Pawn
     */
    public Pawn getPawnInHome(){
        for (int i = 0; i < this.numPawns; i++){
            if(!this.pawns.get(i).isInGame()){
                return this.pawns.get(i);
            }
        }
        return  null;
    }
	
	
	/**
     * Get all the tokens that are in the player's house.
     * @return  Pawn
     */
    public ArrayList<Pawn> getPawnsInHome(){
		ArrayList<Pawn> pawnsInHome = new ArrayList<Pawn>();
        for (int i = 0; i < this.numPawns; i++){
            if(!this.pawns.get(i).isInGame()){
                pawnsInHome.add(pawns.get(i));
            }
        }
		return pawnsInHome;
    }
	

    /**
     * Get the num o equals dice
     * @return  Pawn
     */
    public int getEqualDiceNum() {
        return equalDiceNum;
    }

    /**
     * Get the num o equals dice
     * @return  Pawn
     */
    public void setEqualDiceNum(int num) {
        this.equalDiceNum = num;
    }

    /**
     * Get the last Pawn Move by the player
     * @return  Pawn
     */
    public Pawn getLastPawnMove(){
        return  this.lastPawnMove;
    }

    /**
     * Set the last Pawn Move by the player
     */
    public void setLastPawnMove(Pawn pawn){
        this.lastPawnMove = pawn;
    }

    /**
     * Add equals dice
     */
    public void addEqualsDice() {
        this.equalDiceNum++;
    }

    /**
     * Get the player's pawns in an arrayList
     * @return pawnsPlayer
     */
    public ArrayList<Pawn> getPawns(){
        ArrayList<Pawn> pawnsPlayer = new ArrayList<Pawn>();
        for(int i = 0; i <numPawns; i++){
            pawnsPlayer.add(pawns.get(i));
        }
        return pawnsPlayer;
    }

    /**
     * Add pawns in arrival
     */
    public void addPawnsInArrival() {
        this.pawnsInArrival++;
    }

    /**
     * Add pawns in arrival
     * @param num num pawn
     * @param pawn new pawn
     */
    public void setPawn(int num, Pawn pawn){
        Pawn pawn1 = this.pawns.get(0);
        Square square = pawn1.getActualSquare();
        pawn.setActualSquare(square);
        this.pawns.put(num,pawn);
    }

    /**
     * Add one to the player's turns.
     */
    public void addTurnPlayer(){
        this.turn++;
    }

    /**
     * Get the number of player turns
     * @return num turns
     */
    public int getTurn(){
        return this.turn;
    }

    /**
     * Determines if the player has a pawn of that type.
     * @return have AdvantageousPawns
     */
    public boolean haveAdvantageousPawns(){
        boolean flag = false;
        for(Pawn pawn: getPawns()){
            if(pawn instanceof AdvantageousPawn) flag= true;
        }
        return flag;
    }

    /**
     * Get the tokens of the player of this type
     * @return AdvantageousPawns
     */
    public ArrayList<Pawn> getAdvantageousPawn(){
        ArrayList<Pawn> pawnsPlayer = new ArrayList<Pawn>();
        for(Pawn pawn: getPawns()){
            if(pawn instanceof AdvantageousPawn) pawnsPlayer.add(pawn);
        }
        return pawnsPlayer;
    }

    /**
     * Get the starting index of the player
     * @return index start
     */
    public int getStart(){
        return this.start;
    }

    /**
     * Change the starting rate of the player
     * @param index new index
     */
    public void setStart(int index){
        this.start = index;
    }


}
