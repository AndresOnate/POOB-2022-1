package domain;

import java.awt.*;

public class Arrival extends Square{

    /**
     * Class constructor
     */
    public Arrival (Color color, int number){
        super(color, "Arrival", number);
        this.maxPawns = 4;
    }

    @Override
    /**
     * Add a pawn to the square
     * Update token status (Not in game)
     * @param pawn to add
     */
    public void addPawn(Pawn pawn) {
        pawn.setInGame(false);
        this.pawns.add(pawn);
    }
}
