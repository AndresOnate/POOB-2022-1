package domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class Dice implements Serializable {
    private Random random;

    /**
     * Class constructor
     */
    public Dice(){
        random = new Random();
    }

    public ArrayList<Integer> roll(){
        ArrayList<Integer> roll = new ArrayList<Integer>();
        roll.add(random.nextInt(6) + 1);
        roll.add(random.nextInt(6) + 1);
        return roll;

    }
}
