package domain;

import java.awt.*;

public class JumpingPawn extends Pawn {
    /**
     * Class constructor
     */
    public JumpingPawn(Color color, int number, int jump, Square actualSquare){
        super("Jumping",color,number,jump,actualSquare);
        this.powers = true;
    }
}
