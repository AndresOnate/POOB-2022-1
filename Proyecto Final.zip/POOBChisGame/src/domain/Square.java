package domain;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;

public class Square implements Serializable {

    protected static int maxNumPawns = 2;
    protected Color color;
    protected int number;
    protected int maxPawns;
    protected String type;
    protected boolean barrier;
    protected ArrayList<Pawn> pawns = new ArrayList<Pawn>();


    /**
     * Class constructor
     */
    public Square(Color color, String type, int number){
        this.color = color;
        this.type = type;
        this.number = number;
        this.maxPawns = 2;
    }

    /**
     * Add a pawn to the square
     * @param pawn to add
     */
    public void addPawn(Pawn pawn) {
        validatePawns(pawn.getColor());
        this.pawns.add(pawn);

    }
    /**
     * Add a pawn to the square
     * @param pawn to add
     * @param index index to add
     */
    public void addPawn(Pawn pawn, int index) {
        validatePawns(pawn.getColor());
        this.pawns.add(index,pawn);

    }

    /**
     * Validate if there is a pawn of a different color in the sqaure
     * @param color
     */
    public boolean colorPawnsDifferent(Color color){
        return color != pawns.get(0).getColor();
    }


    /**
     * Del a pawn to the square
     * @param pawn to delete
     */
    public void delPawn(Pawn pawn){
        this.pawns.remove(pawn);
        this.barrier = false;
    }

    /**
     * Get the number associated with the square
     * @return  number
     */
    public int getNumber(){
        return this.number;
    }

    /**
     * Get a certain pawn
     * @return  Pawn
     */
    public Pawn getPawn(Color color, int index){
        for(Pawn pawn: this.pawns){
            if(pawn.getColor().equals(color) && pawn.getNumber() == number){
                pawns.remove(pawn);
                return  pawn;
            }
        }
        return null;
    }

    /**
     * Determines if a box is empty.
     * @return  isEmpty
     */
    public  boolean isEmpty(){
        return this.pawns.size() == 0;
    }

    /**
     * Determine the number of pawns in the box
     * @return  Pawns in square
     */
    public int getNumPawns(){
        return this.pawns.size();
    }

    /**
     * Get a Pawn In Square
     * @return  Pawn
     */
    public Pawn getPawnSquare(){
        return this.pawns.get(0);
    }

    /**
     * Remove a pawn in the square that was sent to jail by another.
     * @return pawn
     */
    public Pawn eat(){
        Pawn pawn = this.pawns.get(0);
        pawns.remove(pawn);
        return pawn;
    }

    /**
     * Determines if the square is a barrier.
     */
    public boolean isBarrier(){
        return  this.barrier;
    }

    /**
     * Determines if the square should become a barrier.
     * @param color Color pawn to be comparated
     */
    public void validatePawns(Color color){
        if(!(pawns.isEmpty())){
            Color pawnOne = pawns.get(0).getColor();
            if (color == pawnOne){
                barrier = true;
            }
        }
    }

    /**
     * Gets the tokens that are on the square.
     * @return pawns
     */
    public ArrayList<Pawn> getPawns(){
        return  this.pawns;
    }

    /**
     * Change the tiles that are on the square.
     * @param pawns new pawns
     */
    public void setPawns(ArrayList<Pawn> pawns){
        this.pawns = pawns;
    }

    /**
     * Determine if the square has room to add more pawns.
     * @return haceSpace
     */
    public boolean haveSpace(){
        return this.pawns.size() < maxNumPawns;
    }

    public Color getColor(){
        return this.color;
    }

}