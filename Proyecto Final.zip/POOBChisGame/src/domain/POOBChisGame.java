package domain;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/**
 * Implementación de la capa de dominio del juego POOBCHIS
 * Andres Camilo Oñate Quimbayo, Nicolas Ariza Barbosa
 * ECI POOB 2022-1
 */

public class POOBChisGame implements Serializable{
	private ArrayList<Color> colorsPlayers = new ArrayList<Color> (Arrays.asList(Color.YELLOW,Color.RED));
	private Player currentPlayer;
	private int numPlayers;
	private Board gameBoard;
	private Dice dices;
	private HashMap<Color,Player> players = new HashMap<Color,Player>();
	private int currentPlayerMove;


	/**
	 * Class constructor
	 */
	public POOBChisGame(int numPlayers){
		this.gameBoard = new Board(numPlayers);
		this.numPlayers =  numPlayers;
		this.dices = new Dice();
		initializePlayers();
	}

	/**
	 *Roll the dice, Evaluates the conditions for a pawn to leave the current player's house
	 * @return dice values
	 */
	public ArrayList<Integer> rollDice() throws POOBChisException{
		ArrayList<Integer> values = dices.roll();
		boolean doubles = (values.get(0) ==  values.get(1));
		if (doubles){
			validateDoubleDice(values);
		}else{
			validateDice(values);
		}
		return values;

	}


	/**
	 * Validate the dice to know if a player can get a pawn
	 * @param values Dice values
	 */
	public void validateDice(ArrayList<Integer> values) throws POOBChisException{
		int sum = 0;
		for(int i:values){
			sum += i;
		};
		if(sum == 5 && currentPlayer.havePawnsInHome()){
			gameBoard.moveToStart(currentPlayer);
			currentPlayer.setEqualDiceNum(0);
			changePlayer();
		}else if(values.contains(5)){
			if(currentPlayer.havePawnsInHome()){
				gameBoard.moveToStart(currentPlayer);
				currentPlayerMove ++;
				currentPlayer.setEqualDiceNum(0);
			}
		}else if(currentPlayer.numPawnsInHome() == 4) {
			changeTurn();
		}else{
			currentPlayerMove = 0;
			currentPlayer.setEqualDiceNum(0);
		}

	}

	public void validateDoubleDice(ArrayList<Integer> values) throws POOBChisException{
		int sum = 0;
		for(int i:values){ sum += i; //Sum the values
		}
		boolean flag = true;
		if(values.get(0) == 5 && values.get(1) == 5){
			if (currentPlayer.numPawnsInHome() > 1) {
				gameBoard.moveToStart(currentPlayer);
				gameBoard.moveToStart(currentPlayer);
				currentPlayerMove = 0;
				flag = false;
			}else if (currentPlayer.havePawnsInHome() && flag){
				gameBoard.moveToStart(currentPlayer);
				currentPlayerMove++;
			}
		}
		currentPlayer.addEqualsDice();
		if (currentPlayer.getEqualDiceNum() > 2){
			gameBoard.threeDiceRule(currentPlayer);
			currentPlayer.setEqualDiceNum(0);
			changePlayer();
		}
	}

	/**
	 * Change the actual PLayer by the next
	 */
	public void changePlayer(){
		currentPlayer.setEqualDiceNum(0);
		this.currentPlayerMove = 2;
		turnGame();
	}

	/**
	 * Initialize the game
	 */
	public void initializePlayers(){
		for(int i = 0; i < this.numPlayers; i++){
			Player player = new Player(colorsPlayers.get(i));
			gameBoard.initializeHomePlayer(player);
			gameBoard.initializeHalls(player.getColor());
			players.put(colorsPlayers.get(i), player);
		}
		turnGame();
	}


	public void changeTurn(){
		this.currentPlayerMove = 0;
		int index = colorsPlayers.indexOf(currentPlayer.getColor());
		if(index + 1 < players.size()){
			currentPlayer = players.get(colorsPlayers.get(index+1));
		}else{
			currentPlayer = players.get(colorsPlayers.get(0));
		}
	}

	/**
	 * Initialize the game Turn
	 */
	public void turnGame(){
		if(currentPlayer == null){
			currentPlayer = players.get(colorsPlayers.get(0));
			currentPlayerMove = 0;
		}else{
			if (currentPlayerMove > 1 && currentPlayer.getEqualDiceNum() == 0) {
				currentPlayer.addTurnPlayer();
				validateAdvantageousPawn();
				changeTurn();
			}
		}
	}


	/**
	 *Play according to the rules of the game, you are given a token, the color
	 * associated with the player and the number of squares to be moved.
	 * @param pawn Pawn to move
	 * @param  dice  a dice value
	 */
	public void play(int pawn, int dice) throws POOBChisException{
		gameBoard.move(pawn, currentPlayer, dice);
		currentPlayerMove++;
		turnGame();
	}

	/**
	 *Get the number of players in the game
	 * @return numPlayers
	 */
	public int getNumPlayers(){
		return this.numPlayers;
	}

	/**
	 *Get the ComodinBoard
	 * @return gameBoard
	 */
	public Board getGameBoard(){
		return  this.gameBoard;
	}

	/**
	 *Get the number of players in the game
	 * @return PawnsInGame
	 */
	public int getNumPawnsInGamePlayer(Color color){
		return players.get(color).getPawnsInGame();
	}

	/**
	 *Get the CurrentPlayer
	 * @return gameBoard
	 */
	public Player getCurrentPlayer() {
		return currentPlayer;
	}


	/**
	 *Determine if the game is already over
	 * @return  endGame
	 */
	public boolean endGame(){
		return gameBoard.finish();
	}

	/**
	 * Pawns in board
	 * @return pawns
	 */
	public int getPawnsInBoard(){
		int cont = 0;
		for(Color color: this.colorsPlayers){
			cont += gameBoard.getPawnsInArrivals(color);
		}
		return this.gameBoard.getPawnsInBoard()+ cont;
	}

	/**
	 *	Returns the HashMap of the players
	 *	@return HashMap<Color,Player>
	 */
	public HashMap<Color,Player> getPlayers(){
		return this.players;
	}


	/**
	 * Gets the pieces that a player can move with a certain value of a die
	 * @return pawns valid player
	 */
	public ArrayList<Pawn> validPawnsPlayer(int dice){
		return gameBoard.validatePawns(currentPlayer.getPawns(), dice );
	}

	/**
	 * Activate the power of a special pawn
	 * @param pawn num pawn number
	 */
	public void activatePowerPawn(int pawn){
		currentPlayerMove++;
		Pawn powerPawn = currentPlayer.getPawn(pawn);
		ArrayList<Square> squares = this.gameBoard.getSquares();
		if(powerPawn instanceof RocketPawn) ((RocketPawn) powerPawn).activatePower(squares);
		if (powerPawn instanceof VacuumPawn) ((VacuumPawn) powerPawn).activatePower(squares, currentPlayer);
		turnGame();

	}

	/**
	 * If the player has pawn of this type, the game
	 * takes care of activating their ability appropriately.
	 */
	public void validateAdvantageousPawn(){
		if(currentPlayer.haveAdvantageousPawns() && (currentPlayer.getTurn() % 2 == 0)){
			for(Pawn pawnAd: currentPlayer.getAdvantageousPawn()){
				int numPawn = pawnAd.getNumber();
				moveAdvantageousPawn(numPawn);
			}
		}
	}

	/**
	 * Move this guy's pawn
	 * @param pawn num pawn number
	 */
	public void moveAdvantageousPawn(int pawn){
		try {
			Pawn pawnAd = currentPlayer.getPawn(pawn);
			int index = pawnAd.getActualSquare().getNumber();
			if (gameBoard.validatePawn(pawnAd,index, index + 3)) gameBoard.move(pawn, currentPlayer, 3);
		}catch (POOBChisException e){}
	}

	/**
	 * Open a file of type .dat containing a POObChisGame
	 * @param file The file with the game information
	 * @return The PoobChisGame contained in the file
	 * @throws POOBChisException When an error occurs when opening
	 */
	public static POOBChisGame open(File file) throws POOBChisException {
		try {
			FileInputStream fileIn = new FileInputStream(file);
			ObjectInputStream objectIn = new ObjectInputStream(fileIn);
			POOBChisGame poobChisGame = (POOBChisGame) objectIn.readObject();
			objectIn.close();
			return poobChisGame;
		} catch (FileNotFoundException e) {
			throw new POOBChisException(POOBChisException.FILE_NOT_FOUND);
		} catch (StreamCorruptedException e) {
			throw new POOBChisException(POOBChisException.CORRUPT_FILE);
		} catch (InvalidClassException e) {
			throw new POOBChisException(POOBChisException.INVALID_CLASS);
		} catch (OptionalDataException e) {
			throw new POOBChisException(POOBChisException.PRIMITIVE_DATA_ERROR);
		} catch (IOException e) {
			throw new POOBChisException(POOBChisException.INPUT_OUTPUT_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new POOBChisException(POOBChisException.OPEN_ERROR);
		}
	}

	/**
	 * Save the POOBChisGame class to a .dat file
	 * @param file The file/directory where you want to save the automata
	 * @throws POOBChisException When an error occurs while saving
	 */
	public void save(File file) throws POOBChisException {
		try {
			FileOutputStream fileOut = new FileOutputStream(file);
			ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
			objectOut.writeObject(this);
			objectOut.close();
		} catch (FileNotFoundException e) {
			throw new POOBChisException(POOBChisException.FILE_NOT_FOUND);
		} catch (InvalidClassException e) {
			throw new POOBChisException(POOBChisException.INVALID_CLASS);
		} catch (NotSerializableException e) {
			throw new POOBChisException(POOBChisException.NOT_SERIALIZABLE);
		} catch (IOException e) {
			throw new POOBChisException(POOBChisException.INPUT_OUTPUT_ERROR);
		} catch (Exception e) {
			e.printStackTrace();
			throw new POOBChisException(POOBChisException.SAVE_ERROR);
		}
	}

}

