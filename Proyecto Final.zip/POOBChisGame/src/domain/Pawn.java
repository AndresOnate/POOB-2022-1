package domain;

import java.awt.*;
import java.io.Serializable;

public class Pawn implements Serializable {
    protected boolean inGame;
    protected String type;
    protected Color color;
    protected int jump = 1;
    protected Square actualSquare;
    protected int number;
    protected int squaresToHome;
    protected boolean arriving;
    protected boolean powers;
    protected int usedPowers;
    protected boolean immortal;
    protected Color abilityColor;

    /**
     * Class constructor
     */
    public Pawn(String type, Color color, int number, int jump, Square actualSquare) {
        this.type = type;
        this.color = color;
        this.jump = jump;
        this.actualSquare = actualSquare;
        this.inGame = false;
        this.number = number;
        this.squaresToHome = 63;
        this.arriving = false;
        this.powers = false;
        this.usedPowers = 0;
        this.immortal = false;
        this.abilityColor = Color.WHITE;
    }

    /**
     * Method to obtain the type of pawn
     * @return String Type
     */
    public String getType(){
        return  this.type;
    }

    /**
     * Method to obtain the color of pawn
     * @return color
     */
    public Color getColor(){
        return  this.color;
    }

    /**
     * Method to obtain the number of pawn
     * @return String Type
     */
    public int getNumber(){
        return  this.number;
    }

    /**
     * Method to obtain the actual square of pawn
     * @return square
     */
    public Square getActualSquare(){
        return this.actualSquare;
    }

    /**
     * Method to change the game state of a pawn.
     */
    public boolean isInGame(){
        return this.inGame;
    }

    /**
     * Method to change the game state of a pawn.
     * @param state new state
     */
    public void setInGame(boolean state){
        this.inGame = state;
    }

    /**
     * Determines if a pawn is in play.
     * @param square square
     */
    public void setActualSquare(Square square){
        this.actualSquare = square;
    }

    /**
     * subtract the number of squares remaining
     * @param squaresToHome
     */
    public void subtractSquares(int squaresToHome){
        this.squaresToHome -= squaresToHome;
    }

    /**
     * Method to obtain the squares to home
     */
    public int getSquaresToHome(){
        return  this.squaresToHome;
    }

    /**
     * Method to change the squares to home
     */
    public void  setSquaresToHome(int squares){
        this.squaresToHome = squares;
    }

    /**
     * Method to change the state arriving
     * @param arrivingState new state
     */
    public void setArriving(boolean arrivingState){
        this.arriving = arrivingState;
    }

    /**
     * Method to get arrival status.
     */
    public boolean isArriving(){
        return this.arriving;
    }

    /**
     * Gets if the pawn has powers
     * @return powers
     */
    public boolean isPowers(){
        return this.powers;
    }

    /**
     * Add one to the times the powers have been used (if the token has them)
     */
    public void addUsedPower(){
        this.usedPowers++;
    }

    /**
     * Number of times used the powers
     * @return num uses
     */
    public int getUsedPowers(){
        return  this.usedPowers;
    }

    /**
     * Gets if the pawn is immortal
     * @return immortal
     */
    public boolean isImmortal(){
        return this.immortal;
    }

    /**
     * Change the pawn's immortal status
     * @param state new state immortal
     */
    public void setImmortal(boolean state){
        this.immortal = state;
    }

    /**
     * Gets the color of teh ability of pawn
     * @return color
     */
    public Color getAbilityColor(){
        return  this.abilityColor;
    }


}
