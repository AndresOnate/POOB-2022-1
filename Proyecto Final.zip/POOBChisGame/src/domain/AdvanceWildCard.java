package domain;

import java.awt.*;
import java.util.ArrayList;

public class AdvanceWildCard extends WildCard{

    /**
     * Class constructor
     */
    public AdvanceWildCard(Color color, int number){
        super(color, "Advance", number);
    }



}
