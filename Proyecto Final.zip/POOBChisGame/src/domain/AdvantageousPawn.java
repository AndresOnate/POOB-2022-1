package domain;

import java.awt.*;

public class AdvantageousPawn extends Pawn{

    /**
     * Class constructor
     */
    public AdvantageousPawn (Color color, int number, int jump, Square actualSquare){
        super("Advantageous",color,number,jump,actualSquare);
        this.powers = true;
        this.abilityColor = new Color(239, 159, 9 );
    }
}
