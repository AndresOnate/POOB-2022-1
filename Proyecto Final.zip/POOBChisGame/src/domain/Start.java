package domain;

import java.awt.*;

public class Start extends Square{

    /**
     * Class constructor
     */
    public Start (Color color, int number){
        super(color, "Start", number);
    }
}
