package domain;

import java.awt.*;
import java.util.ArrayList;

public class RocketPawn extends Pawn{

    /**
     * Class constructor
     */
    public RocketPawn(Color color, int number, int jump, Square actualSquare){
        super("Rocket",color,number,jump,actualSquare);
        this.powers = true;
        this.abilityColor = new Color(9, 239, 214  );

    }

    /**
     * Activate the power of the pawn
     * Jump to the nearest insurance without the need for the value of the dice to be valid
     * @param squares main squares of the board
     */
    public void activatePower(ArrayList<Square> squares){
        Square square = this.getActualSquare();
        int numSquare = square.getNumber();
        Square safe = searchSafe(squares, numSquare);
        square.delPawn(this);
        safe.addPawn(this);
        this.setActualSquare(safe);
        this.addUsedPower();
    }

    /**
     * Find the nearest safe square
     * @param squares main squares of the board
     * @param number number initial index
     * @return Square
     */
    public Square searchSafe(ArrayList<Square> squares, int number){
        for(Square square: squares){
            if((square instanceof Safe && square.haveSpace()) && square.getNumber() > number){
                return square;
            }
        }
        return null;
    }
}
