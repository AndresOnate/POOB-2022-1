package domain;

import java.awt.*;

public class Home extends Square{

    /**
     * Class constructor
     */
    public Home (Color color, int number){
        super(color, "Home", number);
        this.maxPawns = 4;
    }

    @Override
    /**
     * Add a pawn to the square
     * @param pawn to add
     */
    public void addPawn(Pawn pawn) {
        pawn.setInGame(false);
        this.pawns.add(pawn);
    }
}
