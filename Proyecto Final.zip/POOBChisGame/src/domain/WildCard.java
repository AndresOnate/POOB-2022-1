package domain;

import java.awt.*;
import java.util.ArrayList;

public class  WildCard extends Square{

    /**
     * Class constructor
     */
    public WildCard (Color color, String type,  int number){
        super(color, type, number);
    }


}
