package domain;

import java.awt.*;
import java.util.ArrayList;

public class VacuumPawn extends Pawn{

    /**
     * Class constructor
     */
    public VacuumPawn (Color color, int number, int jump, Square actualSquare){
        super("Vacuum",color,number,jump,actualSquare);
        this.powers = true;
        this.abilityColor = new Color(146, 23, 208);

    }

    /**
     * Activate the power of the pawn
     * Bring the pawn (from the same team) that is closest to her back spaces; and takes it
     * to the same square where the vacuum pawn is.
     * @param squares main squares of the board
     * @param player current Player
     */
    public void activatePower(ArrayList<Square> squares, Player player){
        Square square = this.getActualSquare();
        Pawn toMove = null;
        int index = square.getNumber();
        for(Pawn pawn: player.getPawns()){
            int index2 = pawn.getActualSquare().getNumber();
            if((index2 < index) && (index-index2) <= 12){
                toMove = pawn;
                break;
            }
        }
        if(toMove != null){
            Square moveSquare = toMove.getActualSquare();
            moveSquare.delPawn(toMove);
            toMove.setActualSquare(square);
            square.addPawn(toMove);
        }


    }
}
