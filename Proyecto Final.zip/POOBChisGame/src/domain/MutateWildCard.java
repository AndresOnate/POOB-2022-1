package domain;

import java.awt.*;
import java.lang.reflect.InvocationTargetException;

public class MutateWildCard extends WildCard{

    /**
     * Class constructor
     */
    public MutateWildCard (Color color, int number){
        super(color, "Mutate", number);
    }


    /**
     * Create an instance of a file of the class that is
     * passed by parameter and update the existing one. (mutates)
     * @param type pawn type
     * @return pawn
     * @throws Exception POOBChisException
     */
    public Pawn mutatePawn(String type) throws POOBChisException{
        try {
            Pawn pawn = this.getPawnSquare();
            Color color =  pawn.getColor();
            int number = pawn.getNumber();
            Class cls = Class.forName("domain."+type);
            Class[] parameterType = {Color.class, int.class, int.class, Square.class};
            Pawn newPawn = (Pawn) cls.getDeclaredConstructor(parameterType).newInstance(color, number,1,this);
            newPawn.setInGame(true);
            newPawn.setSquaresToHome(pawn.getSquaresToHome());
            this.delPawn(pawn);
            this.addPawn(newPawn);
            return newPawn;
        } catch (ClassNotFoundException e) {
            throw new POOBChisException(POOBChisException.CLASS_NOT_FOUND);
        } catch (InstantiationException e) {
            throw new POOBChisException(POOBChisException.INSTANTIATION_ERROR);
        } catch (NoSuchMethodException e) {
            throw new POOBChisException(POOBChisException.NOT_METHOD_FOUND);
        } catch (InvocationTargetException e) {
            throw new POOBChisException(POOBChisException.INVOCATION_ERROR);
        } catch (Exception e) {
            e.printStackTrace();
            throw new POOBChisException(POOBChisException.CREATE_ERROR);
        }



    }
}
