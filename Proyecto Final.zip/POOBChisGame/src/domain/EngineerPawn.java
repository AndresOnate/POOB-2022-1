package domain;

import java.awt.*;
import java.util.ArrayList;

public class EngineerPawn extends Pawn{

    /**
     * Class constructor
     */
    public EngineerPawn(Color color, int number, int jump, Square actualSquare){
        super("Engineer",color,number,jump,actualSquare);
        this.powers = true;
        this.abilityColor = new Color(239, 9, 225  );

    }

    /**
     * Activate the power of the pawn
     * Turn the arrival square into a safe square
     * @param squares main squares of the board
     */
    public void activatePower(ArrayList<Square> squares){
        Square square = this.getActualSquare();
        int index = square.getNumber();
        ArrayList<Pawn> pawns = square.getPawns();
        squares.remove(square);
        Safe safe = new Safe(this.getColor(),index);
        safe.setPawns(pawns);
        squares.add(index,safe);
        this.addUsedPower();
    }
}
