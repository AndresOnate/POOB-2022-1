package domain;

import java.awt.*;

public class BackWildCard extends WildCard{

    /**
     * Class constructor
     */
    public BackWildCard(Color color, int number){
        super(color, "Back", number);
    }

    /**
     * Class constructor
     * Validate the move to activate the pawn's power.
     * When going back, it must not be behind the player's starting square.
     * @param player player validate
     * @param indexA index five squares back
     */
    public boolean validateMove(Player player, int indexA){
        return indexA > player.getStart();
    }

}
