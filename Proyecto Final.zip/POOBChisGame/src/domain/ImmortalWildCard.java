package domain;

import java.awt.*;

public class ImmortalWildCard extends WildCard {

    /**
     * Class constructor
     */

    public ImmortalWildCard(Color color, int number){
        super(color, "Immortal", number);
    }

    @Override
    /**
     * Add a pawn to the square
     * @param pawn to add
     */
    public void addPawn(Pawn pawn) {
        pawn.setImmortal(true);
        this.pawns.add(pawn);
    }
}
