package domain;

import java.awt.*;

public class Safe extends Square{

    /**
     * Class constructor
     */

    public Safe (Color color, int number){
        super(color, "Safe", number);
    }

    @Override
    /**
     * Add a pawn to the square
     * @param pawn to add
     */
    public void addPawn(Pawn pawn) {
        if( (!pawns.isEmpty()) && pawns.get(0).getColor() != pawn.getColor() ){
            this.barrier = true;
        }
        this.pawns.add(pawn);
    }
}
