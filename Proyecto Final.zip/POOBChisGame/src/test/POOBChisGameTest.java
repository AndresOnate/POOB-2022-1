package domain;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class POOBChisGameTest {

    @Before
    public void setUp() {

    }

    @Test
    public void shouldCreatePARCHISGame(){
        POOBChisGame parchis= new POOBChisGame(2);
        assertEquals(2,parchis.getNumPlayers());
    }

    @Test
    public void shouldRollDice() throws POOBChisException{
        POOBChisGame parchis= new POOBChisGame(2);
        ArrayList<Integer> a = new ArrayList<Integer>();
        a.add(1);
        a.add(2);
        assertEquals(a.size(), parchis.rollDice().size());
    }

    @Test
    public void shouldInicializeBoard(){
        POOBChisGame parchis= new POOBChisGame(2);
        Board gameBoard = parchis.getGameBoard();
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        assertEquals(68, gameBoard.getSquares().size());
    }


    @Test
    public void shouldChangePlayer1() throws POOBChisException{
        POOBChisGame parchis= new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer> (Arrays.asList(60,5));
        parchis.validateDice(dice);
        parchis.play(0, 60);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(62,5));
        parchis.validateDice(dice);
        assertEquals(2,parchis.getPawnsInBoard());
        parchis.play(0,62);
        assertEquals(2,parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,4);
        assertEquals(2,parchis.getPawnsInBoard());
    }

    @Test
    public void shouldChangePlayer2() throws POOBChisException{
        POOBChisGame parchis= new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer> (Arrays.asList(5,5));
        parchis.validateDoubleDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        assertEquals(2,parchis.getPawnsInBoard());
    }

    @Test
    public void shouldChangePlayer3() throws POOBChisException{
        POOBChisGame parchis= new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer> (Arrays.asList(5,5));
        parchis.validateDoubleDice(dice);
        dice = new ArrayList<Integer> (Arrays.asList(1,2));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(1,2);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(2,3));
        parchis.validateDice(dice);
        assertEquals(3,parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(1,2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,1);
        parchis.play(1,2);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(6,6));
        parchis.validateDoubleDice(dice);
        parchis.play(0,6);
        parchis.play(0,6);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(4,4));
        parchis.validateDoubleDice(dice);
        parchis.play(0,4);
        parchis.play(0,4);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer> (Arrays.asList(3,3));
        parchis.validateDoubleDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
    }

    @Test
    public void shouldChangePlayer4() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(5, 5));
        parchis.validateDoubleDice(dice);
        dice = new ArrayList<Integer> (Arrays.asList(1,2));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(1,2);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(2, 3));
        parchis.validateDice(dice);
        assertEquals(3, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0, 1);
        parchis.play(1, 2);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(6, 6));
        parchis.validateDoubleDice(dice);
        parchis.play(0, 6);
        parchis.play(0, 6);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(4, 4));
        parchis.validateDoubleDice(dice);
        parchis.play(0, 4);
        parchis.play(0, 4);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(5, 5));
        parchis.validateDoubleDice(dice);
        assertEquals(4, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());

    }

    @Test
    public void shouldMove() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(63, 1));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,63);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(63, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        parchis.play(0,63);
        parchis.play(0,1);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(2, 4));
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,2);
        parchis.play(0,4);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
    }

    @Test
    public void shouldMove2() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(65, 1));
        parchis.validateDice(dice);
        parchis.play(0,65);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        dice = new ArrayList<Integer>(Arrays.asList(27, 6));
        parchis.validateDice(dice);
        parchis.play(0,27);
        parchis.play(0,5);
        assertEquals(2, parchis.getPawnsInBoard());
    }

    @Test
        public void shouldEatPawn() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 1));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(35, 1));
        parchis.validateDice(dice);
        parchis.play(0,35);
        parchis.play(0,1);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        assertEquals(1, parchis.getPawnsInBoard());
    }


    @Test
    public void shouldCreateBlock() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(5, 5));
        parchis.validateDoubleDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 3));
        parchis.validateDoubleDice(dice);
        parchis.play(0,3);
        parchis.play(1,3);
        assertEquals(2, parchis.getPawnsInBoard());
        dice = new ArrayList<Integer>(Arrays.asList(1, 6));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,1);
        parchis.play(1,3);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
    }

    @Test
    public void shouldNotEatPawn() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(28, 1));
        parchis.validateDice(dice);
        parchis.play(0,23);
        parchis.play(0,1);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 4));
        parchis.validateDice(dice);
        parchis.play(0,3);
        parchis.play(0,4);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(11, 6));
        parchis.validateDice(dice);
        parchis.play(0,11);
        parchis.play(0,6);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 2));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(0,2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 1));
        parchis.validateDice(dice);
        parchis.play(0,3);
        parchis.play(0,1);
        assertEquals(1, parchis.getPawnsInBoard());

    }

    @Test
    public void shouldEngineerPawn() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        Square square = new Square(Color.YELLOW,"Normal",100);
        EngineerPawn engineerPawn = new EngineerPawn(Color.yellow, 0,1,square );
        parchis.getCurrentPlayer().setPawn(0,engineerPawn);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(0,3);
        assertEquals(2, parchis.getPawnsInBoard());

    }

    @Test
    public void RocketPawn() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        Square square = new Square(Color.YELLOW,"Normal",100);
        RocketPawn rocketPawn = new RocketPawn(Color.yellow, 0,1,square );
        parchis.getCurrentPlayer().setPawn(0,rocketPawn);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        parchis.activatePowerPawn(0);
        assertEquals(2, parchis.getPawnsInBoard());

    }

    @Test
    public void ShouldVacuum() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        Square square = new Square(Color.YELLOW,"Normal",100);
        VacuumPawn vacuumPawn = new VacuumPawn(Color.yellow, 0,1,square );
        parchis.getCurrentPlayer().setPawn(0,vacuumPawn);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(5, 5));
        parchis.validateDoubleDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        assertEquals(2, parchis.getPawnsInBoard());
        dice = new ArrayList<Integer>(Arrays.asList(7, 1));
        parchis.validateDice(dice);
        parchis.play(0,7);
        assertEquals(2, parchis.getPawnsInBoard());
        parchis.activatePowerPawn(0);
        assertEquals(2, parchis.getPawnsInBoard());

    }

    @Test
    public void ShouldAdvantageous() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        Square square = new Square(Color.YELLOW,"Normal",100);
        AdvantageousPawn advantageousPawn = new AdvantageousPawn(Color.yellow, 0,1,square );
        parchis.getCurrentPlayer().setPawn(0,advantageousPawn);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,1);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());

    }

    @Test
    public void ShouldAdvanceWildCard() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        AdvanceWildCard advanceWildCard = new AdvanceWildCard(Color.yellow,9);
        parchis.getGameBoard().setSquare(advanceWildCard,9);
        assertEquals(0, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,4);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,1);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
    }

    @Test
    public void ShouldBackWildCard() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        BackWildCard backWildCard = new BackWildCard(Color.yellow,15);
        parchis.getGameBoard().setSquare(backWildCard ,15);
        assertEquals(0, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,10);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,1);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
    }

    @Test
    public void ShouldJailWildCard() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        JailWildCard jailWildCard = new JailWildCard(Color.yellow,15);
        parchis.getGameBoard().setSquare(jailWildCard ,15);
        assertEquals(0, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,10);
        assertEquals(1, parchis.getPawnsInBoard());
    }


    @Test
    public void ShouldOutJailWildCard() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        OutJailWildCard outJailWildCard = new OutJailWildCard(Color.yellow,15);
        parchis.getGameBoard().setSquare(outJailWildCard ,15);
        assertEquals(0, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,10);
        assertEquals(3, parchis.getPawnsInBoard());
    }

    @Test
    public void ShouldImmortalWildCard() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        ImmortalWildCard immortalWildCard = new ImmortalWildCard(Color.yellow,15);
        parchis.getGameBoard().setSquare(immortalWildCard ,15);
        assertEquals(0, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(1, 3));
        parchis.validateDice(dice);
        parchis.play(0,10);
        assertEquals(2, parchis.getPawnsInBoard());
    }

    @Test
    public void ShouldMutateWildCard()  {
        try {
            POOBChisGame parchis = new POOBChisGame(2);
            MutateWildCard mutateWildCard= new MutateWildCard(Color.yellow,15);
            parchis.getGameBoard().setSquare(mutateWildCard ,15);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(2, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(1, 3));
            parchis.validateDice(dice);
            parchis.play(0,10);
            assertEquals(2, parchis.getPawnsInBoard());
        }catch (POOBChisException e){
            assertEquals(e.getMessage(), POOBChisException.CREATE_ERROR);
        }
    }

    @Test
    public void ShouldChangePlayer() throws POOBChisException {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(5, 5));
            parchis.validateDoubleDice(dice);
            assertEquals(3, parchis.getPawnsInBoard());
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(4, 1));
            parchis.validateDice(dice);
            assertEquals(Color.YELLOW, parchis.getCurrentPlayer().getColor());
            assertEquals(4, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        }catch (POOBChisException e){
            assertEquals(POOBChisException.SQUARE_FILLED, e.getMessage());
        }

    }

    @Test
    public void ShouldChangePlayer2()  {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(4, 3));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(1, 1));
            parchis.validateDoubleDice(dice);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(5, 6));
            parchis.validateDice(dice);
            parchis.play(0,6);
            assertEquals(Color.YELLOW, parchis.getCurrentPlayer().getColor());
            assertEquals(1, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        }catch (POOBChisException e){

        }

    }
    @Test
    public void ShouldChangePlayer3()  {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(1, 3));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(2, 5));
            parchis.validateDice(dice);
            parchis.play(0,2);
            assertEquals(1, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(4, 4));
            parchis.validateDoubleDice(dice);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(5, 6));
            parchis.validateDice(dice);
            parchis.play(0,6);
            dice = new ArrayList<Integer>(Arrays.asList(6, 2));
            parchis.validateDice(dice);
            parchis.play(0,6);
            parchis.play(0,2);
            assertEquals(2, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        }catch (POOBChisException e){

        }
    }

    @Test
    public void ShouldChangePlayer4()  {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(0, parchis.getPawnsInBoard());
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(2, 5));
            parchis.validateDice(dice);
            parchis.play(0,2);
            assertEquals(1, parchis.getPawnsInBoard());
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        }catch (POOBChisException e){

        }
    }

    @Test
    public void shouldEatPawn2() throws POOBChisException {
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(55, 1));
        parchis.validateDice(dice);
        parchis.play(0,51);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(17, 1));
        parchis.validateDice(dice);
        parchis.play(0,17);
        parchis.play(0,1);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        assertEquals(1, parchis.getPawnsInBoard());
    }

    @Test
    public void shouldMoveCross() throws POOBChisException {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(3, parchis.getPawnsInBoard());
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(28, 1));
            parchis.validateDice(dice);
            parchis.play(0,28);
            parchis.play(0,2);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        }catch (Exception e){}

    }


    @Test
    public void shouldBlock() throws POOBChisException {
        try{
            POOBChisGame parchis = new POOBChisGame(2);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(3, 2));
            parchis.validateDice(dice);
            assertEquals(3, parchis.getPawnsInBoard());
            assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
            dice = new ArrayList<Integer>(Arrays.asList(32, 6));
            parchis.validateDice(dice);
            parchis.play(0,32);
            parchis.play(0,6);
        }catch (POOBChisException e){
            assertEquals(POOBChisException.SQUARE_BLOCK, e.getMessage());

        }


    }
    @Test
    public void shouldMoveInToHALL() throws POOBChisException{
        POOBChisGame parchis = new POOBChisGame(2);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        ArrayList<Integer> dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(3, 2));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(63, 1));
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,63);
        parchis.play(0,1);
        assertEquals(2, parchis.getPawnsInBoard());
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(63, 2));
        parchis.validateDice(dice);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
        parchis.play(0,63);
        parchis.play(0,1);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        dice = new ArrayList<Integer>(Arrays.asList(2, 4));
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.validateDice(dice);
        assertEquals(Color.yellow, parchis.getCurrentPlayer().getColor());
        parchis.play(0,2);
        parchis.play(0,4);
        assertEquals(Color.red, parchis.getCurrentPlayer().getColor());
    }

    @After
    public void tearDown(){
    }
}
