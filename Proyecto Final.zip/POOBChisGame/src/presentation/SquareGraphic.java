package presentation;

import domain.*;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class SquareGraphic extends JPanel {

    private int pawns;
	private String miTipo;
	private Color myColor;

    public SquareGraphic(int pawns, String type, Color squareColor){
		this.setBackground(squareColor);
		myColor = squareColor;
		if (type.equals("Horizontal")){
			this.setLayout(new GridLayout(pawns, 1));
		} else if (type.equals("Vertical")){
			this.setLayout(new GridLayout(1, pawns));
		}else{
			this.setLayout(new GridLayout(2, 2));
		}
        this.pawns = pawns;
		this.miTipo = type;
        for (int i = 0; i < pawns; i++){
            PawnGraphic pawn = new PawnGraphic(this, type, squareColor);
			pawn.setBackground(squareColor);
            add(pawn);
        }
    }
	
	
	public void refresh (int newPawnsStored, ArrayList<Pawn> pawnsStored){
		if (this.miTipo.equals("Horizontal")){
			this.setLayout(new GridLayout((int) newPawnsStored, 1));
		} else if (this.miTipo.equals("Vertical")){
			this.setLayout(new GridLayout(1, newPawnsStored));
		}else{
			this.setLayout(new GridLayout(2, 2));
		}
        this.pawns = newPawnsStored;
        for (int i = 0; i < newPawnsStored; i++){
			PawnGraphic pawn = new PawnGraphic(this, this.miTipo, pawnsStored.get(i).getColor(), pawnsStored.get(i).getAbilityColor());
			pawn.setBackground(this.myColor);
            add(pawn);
		}
	}
	
	
	public int getNumPawnsSaved(){
		return this.pawns;
	}
	
	
	public Component[] getPawnsSaved(){
		return this.getComponents();
	}
	
	public void setColor(Color newColor){
		this.myColor = newColor;
		this.setBackground(newColor);
	} 
}