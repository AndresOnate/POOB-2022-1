package presentation;

import javax.swing.*;
import java.awt.*;

public class Welcome extends JFrame {
    private JLabel logo;
    private JPanel buttons;
    private JButton play;
    private JButton gameModes;
    private Image backg;
    private JPanel mainPanel;
    private JPanel iconPane;
    private JPanel bottonPanel;
    FondPanel fondo = new FondPanel();

    public Welcome(){
        prepareElements();
        prepareActions();
    }

    private void prepareElements(){
        setTitle("POOBChis");
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int height = pantalla.height;
        int width = pantalla.width;
        setSize(width, height);
        setLocationRelativeTo(null);
        preparePanels();
        prepareButton();
    }

    private void preparePanels(){
        mainPanel = new JPanel(new BorderLayout());
        iconPane = new JPanel(new BorderLayout());
        bottonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        iconPane.setBackground(new Color(9, 23, 55));
        bottonPanel.setBackground(new Color(9, 23, 55));
        logo = new JLabel();
        iconPane.add(logo);
        mainPanel.add(fondo, BorderLayout.CENTER);
        mainPanel.add(bottonPanel, BorderLayout.SOUTH);
        add(mainPanel);
    }

    private void prepareActions() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void prepareButton(){
        int x = this.getWidth() / 4;
        int y = this.getHeight() / 4;
        int dx = x / 2;
        int dy = y / 2;
        play = new JButton("Play");
        play.setBackground(new Color(119, 45, 227));
        gameModes = new JButton("Game Modes");
        gameModes.setBackground(new Color(119, 45, 227));
        bottonPanel.add(play);
        bottonPanel.add(gameModes);
        play.setForeground(Color.WHITE);
        gameModes.setForeground(Color.WHITE);
    }


    public static void main(String args[]){
        Welcome gui = new Welcome();
        gui.setVisible(true);
    }


}
