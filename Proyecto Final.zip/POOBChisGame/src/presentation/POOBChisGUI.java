package presentation;


import domain.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import javax.swing.*;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.BorderLayout;
import java.util.*;
import javax.swing.filechooser.FileNameExtensionFilter;



public class POOBChisGUI extends JFrame {
    private POOBChisGame game;
	private static Integer squareContFront = 1;
	private static Integer squareContBack = 67;

    /*Menu Items*/
    /*Menu Elements*/
    private JMenuItem nuevo;
    private JMenuItem abrir;
    private JMenuItem guardar;
    private JMenuItem salir;
	// Game table
	private JPanel gameBoard;
	private HashMap<Color,SquareGraphic> houses = new HashMap<Color,SquareGraphic>();
	private TreeMap<Integer,SquareGraphic> squares = new TreeMap<Integer,SquareGraphic>();
	private Color borderColor = new Color(169, 169, 169);
	private ArrayList<Square> logicSquares;
	private HashMap<Color,Integer> logicHouses = new HashMap<Color, Integer>();
	private HashMap<Color, Player> logicPlayers;
	private HashMap<Color, ArrayList<Integer>> playersPawnsOrder = new HashMap<Color, ArrayList<Integer>>();
	private JRadioButton pawn1 = new JRadioButton("1",false);
	private JRadioButton pawn2 = new JRadioButton("2",false);
	private JRadioButton pawn3 = new JRadioButton("3",false);
	private JRadioButton pawn4 = new JRadioButton("4",false);
	private JRadioButton diceSelection1 = new JRadioButton("0",false);
	private JRadioButton diceSelection2 = new JRadioButton("0",false);
	private JRadioButton yesSelection = new JRadioButton("Yes", false);
	// Interaction board
	private JPanel interactions;
	private JPanel gameInteractions;
	private JPanel matchInfo;
	private JPanel dicePanel;
	private JPanel playersInfo;
	private JButton rollTheDice;
	private JLabel dice1;
	private JLabel dice2;
	private JPanel player1;
	private JPanel player2;
	private JLabel fichas1;
	private JLabel fichasCoronadas1;
	private JLabel fichasEncarceladas1;
	private JLabel fichas2;
	private JLabel fichasCoronadas2;
	private JLabel fichasEncarceladas2;
	private JLabel turno;
	private JLabel gameMode;
	private JLabel noParesEnPartida;
	private JLabel logo;
	private JPanel buttons;
	private JButton play;
	private JButton gameModes;
	private Image backg;
	private JPanel mainPanel;
	private JPanel iconPane;
	private JPanel bottonPanel;
	private FondPanel fondo = new FondPanel();
	private DicePanel newDice1;
	private DicePanel newDice2;

	private static POOBChisGUI solitario = null;

	public POOBChisGUI(){
		game = new POOBChisGame(2);
		Welcome();
	}

	private void Welcome(){
		prepareElementsWelcome();
		prepareActionsWelcome();
	}

	private void prepareElementsWelcome(){
		setTitle("POOBChis");
		Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int height = pantalla.height;
        int width = pantalla.width;
        this.setSize(2*width/3, 2*height/3);
        this.setLocationRelativeTo(null);
		preparePanels();
		prepareButton();
	}

	private void preparePanels(){
		mainPanel = new JPanel(new BorderLayout());
		iconPane = new JPanel(new BorderLayout());
		bottonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		iconPane.setBackground(new Color(9, 23, 55));
		bottonPanel.setBackground(new Color(9, 23, 55));
		logo = new JLabel();
		iconPane.add(logo);
		mainPanel.add(fondo, BorderLayout.CENTER);
		mainPanel.add(bottonPanel, BorderLayout.SOUTH);
		add(mainPanel);
	}

	private void prepareActionsWelcome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		play.addActionListener(e -> actionWelcome());
	}

	private void prepareButton(){
		int x = this.getWidth() / 4;
		int y = this.getHeight() / 4;
		int dx = x / 2;
		int dy = y / 2;
		play = new JButton("Play");
		play.setBackground(new Color(119, 45, 227));
		play.setForeground(Color.WHITE);
		gameModes = new JButton("Game Modes");
		gameModes.setBackground(new Color(119, 45, 227));
		bottonPanel.add(play);
		//bottonPanel.add(gameModes);
		gameModes.setForeground(Color.WHITE);
	}

	public void actionWelcome(){
		mainPanel.removeAll();
		mainPanel.revalidate();
		this.getContentPane().removeAll();
		this.getContentPane().revalidate();
		logicSquares = game.getGameBoard().getSquares();
		logicPlayers = game.getPlayers();
		refreshDataHouses();
		prepareElements();
		prepareActions();
	}


	///
	
	private void refreshDataHouses(){
		logicPlayers = game.getPlayers();
		logicHouses.clear();
		for (Color c: logicPlayers.keySet()){
			int value = logicPlayers.get(c).numPawnsInHome();
			logicHouses.put(c, value);
		}
	}

    private void prepareElements(){
		this.setLayout(new GridLayout(1,2));
        prepareElementsBoard();
        prepareElementsMenu();
		prepareElementsGameInfo();
        setTitle("POOBChis");
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int height = pantalla.height;
        int width = pantalla.width;
        this.setSize(10*width/11, 10*height/11);
        this.setLocationRelativeTo(null);
		this.setResizable(false);
    }

     private void prepareElementsBoard(){
		Integer[] sample = new Integer[] {0,1,2,3};
		gameBoard = new JPanel(new GridLayout(3,3));
		gameBoard.setBorder(new CompoundBorder(new EmptyBorder(5,5,5,5),
													new TitledBorder("POOBChis")));
		
		SquareGraphic house1 = new SquareGraphic(4, "House", Color.YELLOW);
		playersPawnsOrder.put(Color.YELLOW, new ArrayList<Integer>(Arrays.asList(sample)));
		house1.setBackground(Color.YELLOW);
		gameBoard.add(house1);
		houses.put(Color.YELLOW, house1);
		prepareSquaresVertical(Color.YELLOW, false);
		
		SquareGraphic house2 = new SquareGraphic(4, "House", Color.GREEN);
		playersPawnsOrder.put(Color.GREEN, new ArrayList<Integer>(Arrays.asList(sample)));
		house2.setBackground(Color.GREEN);
		gameBoard.add(house2);
		houses.put(Color.GREEN, house2);
		prepareSquaresHorizontal(Color.BLUE, true);
		
		
		// JLabel middle = new JLabel();
		// middle.setIcon(new ImageIcon("src/images/Middle.PNG"));
		// gameBoard.add(middle);
		MiddlePanel middlePanel = new MiddlePanel(); //Panel con la imagen
		gameBoard.add(middlePanel);
		prepareSquaresHorizontal(Color.GREEN, false);
		
		
		SquareGraphic house3 = new SquareGraphic(4, "House", Color.BLUE);
		playersPawnsOrder.put(Color.BLUE, new ArrayList<Integer>(Arrays.asList(sample)));
		house3.setBackground(Color.BLUE);
		gameBoard.add(house3);
		houses.put(Color.BLUE, house3);
		prepareSquaresVertical(Color.RED, true);
		
		
		SquareGraphic house4 = new SquareGraphic(4, "House", Color.RED);
		playersPawnsOrder.put(Color.RED, new ArrayList<Integer> (Arrays.asList(sample)));
		house4.setBackground(Color.RED);
		gameBoard.add(house4);
		houses.put(Color.RED, house4);
		
		this.add(gameBoard);
    }
	
	
	private void prepareSquaresHorizontal(Color color, boolean transversal){
		int column1 = 0;
		int column2 = 0;
		if (transversal){
			column1 = 4;
			column2 = 0;
			squareContFront = 16;
		}else{
			column1 = 3;
			column2 = 7;
		}
		JPanel temp = new JPanel(new GridLayout(3,8));
		for (int i = 0; i < 3; i++){
			if (!transversal && i == 2){
				squareContBack = 43;
			}else if(transversal && i == 1){
				squareContFront = 17;
			}
			for(int j = 0; j < 8; j++){
				SquareGraphic square = new SquareGraphic(0, "Horizontal", Color.WHITE); 
				square.setBorder(BorderFactory.createLineBorder(borderColor,1));
				if (i == 1){
					square.setColor(color);
				}
				if (i == 0 && j == column1){
					if (transversal){
						square.setColor(Color.GRAY);
					}else{
						square.setColor(color);
					}
				}
				if (i == 2 && j == column1){
					if (transversal){
						square.setColor(color);
					}else{
						square.setColor(Color.GRAY);
					}
				}
				if (i == 1 && j == column2){
					square.setColor(Color.GRAY);
					if (transversal){
						squares.put(squareContFront, square);
						squareContFront++;
					}else{
						squares.put(squareContBack, square);
						squareContBack--;
					}
				}
				if (i == 0){
					if (transversal){
						squares.put(squareContFront, square);
						squareContFront--;
					}else{
						squares.put(squareContBack, square);
						squareContBack--;
					}
				}
				if (i == 2){
					if (transversal){
						squares.put(squareContFront, square);
						squareContFront++;
					}else{
						squares.put(squareContBack, square);
						squareContBack++;
					}
					
				}
				temp.add(square);
			}
		}
		if (!transversal){
			squareContBack = 42;
		}
		gameBoard.add(temp);
	}
	
	
	private void prepareSquaresVertical(Color color, boolean transversal){
		int row1 = 0;
		int row2 = 0;
		if (transversal){
			row1 = 3;
			row2 = 7;
		}else{
			row1 = 4;
			row2 = 0;
		}
		JPanel temp = new JPanel(new GridLayout(8,3));
		for (int i = 0; i < 8; i++){
			for(int j = 0; j < 3; j++){
				SquareGraphic square = new SquareGraphic(0, "Vertical", Color.WHITE); 
				square.setBorder(BorderFactory.createLineBorder(borderColor,1));
				if (j == 1){
					square.setColor(color);
				}
				if (j == 0 && i == row1){
					if (transversal){
						square.setColor(Color.GRAY);
					}else{
						square.setColor(color);
					}
				}
				if (j == 2 && i == row1){
					if (transversal){
						square.setColor(color);
					}else{
						square.setColor(Color.GRAY);
					}
				}
				if (j == 1 && i == row2){
					square.setColor(Color.GRAY);
					if (transversal){
						squares.put(squareContFront, square);
						squareContFront++;
					}else{
						squares.put(0, square);
					}
				}
				if (j == 0){
					squares.put(squareContFront, square);
					squareContFront++;
				}
				if (j == 2){
					squares.put(squareContBack, square);
					squareContBack--;
				}
				temp.add(square);
			}
		}
		gameBoard.add(temp);
	}
	
	
	private void prepareElementsGameInfo(){
		interactions = new JPanel(new GridLayout(2,1));
		gameInteractions = new JPanel(new GridLayout(1,2));
		dicePanel = new JPanel(new GridLayout(2,1));
		matchInfo = new JPanel(new GridLayout(3,1));
		playersInfo = new JPanel(new GridLayout(1,2));
		prepareElementsDicePanel();
		prepareElementsMatchInfo();
		prepareElementsPlayersInfo();
		interactions.add(gameInteractions);
		interactions.add(playersInfo);
		this.add(interactions);
	}
	
	
	private void prepareElementsDicePanel(){
		dicePanel.setBorder(new CompoundBorder(new EmptyBorder(5,5,5,5),
													new TitledBorder("Dados")));
		JPanel general = new JPanel(new GridLayout(1,2));
		// dice1 = new JLabel();
		// dice2 = new JLabel();
		// dice1.setIcon(new ImageIcon("src/images/dice1.PNG"));
		// dice2.setIcon(new ImageIcon("src/images/dice1.PNG"));
		// general.add(dice1);
		// general.add(dice2);
		newDice1 = new DicePanel();
		newDice2 = new DicePanel();
		general.add(newDice1);
		general.add(newDice2);
		rollTheDice = new JButton("Lanzar");	
		dicePanel.add(general);
		dicePanel.add(rollTheDice);
		gameInteractions.add(dicePanel);
	}
	
	
	private void prepareElementsMatchInfo(){
		matchInfo.setBorder(new CompoundBorder(new EmptyBorder(5,5,5,5),
													new TitledBorder("Informacion de la partida")));
		turno = new JLabel("Turno: Jugador Amarillo");
		noParesEnPartida = new JLabel("No. de pares obtenidos en el turno: 0");
		gameMode = new JLabel("Modo de juego: Jugador vs Jugador");
		matchInfo.add(turno);
		matchInfo.add(noParesEnPartida);
		matchInfo.add(gameMode);
		gameInteractions.add(matchInfo);
	}
	
	
	private void prepareElementsPlayersInfo(){
		// Panel del jugador 1
		
		player1 = new JPanel(new GridLayout(3,1));
		player1.setBorder(new CompoundBorder(new EmptyBorder(5,5,5,5),
													new TitledBorder("Jugador 1")));

		fichas1 = new JLabel("No. de fichas en el tablero: 0");
		fichasCoronadas1 = new JLabel("No. de fichas aseguradas: 0");
		fichasEncarceladas1 = new JLabel("No. de fichas encarceladas: 4");
		player1.add(fichas1);
		player1.add(fichasCoronadas1);
		player1.add(fichasEncarceladas1);
		// Panel del jugador 2
		player2 = new JPanel(new GridLayout(3,1));
		player2.setBorder(new CompoundBorder(new EmptyBorder(5,5,5,5),
													new TitledBorder("Jugador 2")));
		fichas2 = new JLabel("No. de fichas en el tablero: 0");
		fichasCoronadas2 = new JLabel("No. de fichas aseguradas: 0");
		fichasEncarceladas2 = new JLabel("No. de fichas encarceladas: 4");
		player2.add(fichas2);
		player2.add(fichasCoronadas2);
		player2.add(fichasEncarceladas2);
		playersInfo.add(player1);
		playersInfo.add(player2);
		
	}
	
	private void refreshPlayersInfo(){
		logicPlayers = game.getPlayers();
		int coronadas1 = Math.abs(logicPlayers.get(Color.YELLOW).getPawnsInGame() + logicPlayers.get(Color.YELLOW).numPawnsInHome() - 4);
		int coronadas2 = Math.abs(logicPlayers.get(Color.RED).getPawnsInGame() + logicPlayers.get(Color.RED).numPawnsInHome() - 4);
		player1.removeAll();
		player1.updateUI();
		player1.repaint();
		player2.removeAll();
		player2.updateUI();
		player2.repaint();
		
		
		player1.setLayout(new GridLayout(3,1));
		fichas1.setText("No. de fichas en el tablero: " + (logicPlayers.get(Color.YELLOW).getPawnsInGame()));
		player1.add(fichas1);
		fichasCoronadas1.setText("No. de fichas aseguradas: " + (coronadas1));
		player1.add(fichasCoronadas1);
		fichasEncarceladas1.setText("No. de fichas encarceladas: " + (logicPlayers.get(Color.YELLOW).numPawnsInHome()));
		player1.add(fichasEncarceladas1);
		player1.revalidate();
		
		player2.setLayout(new GridLayout(3,1));
		fichas2.setText("No. de fichas en el tablero: " + (logicPlayers.get(Color.RED).getPawnsInGame()));
		player2.add(fichas2);
		fichasCoronadas2.setText("No. de fichas aseguradas: " + (coronadas2));
		player2.add(fichasCoronadas2);
		fichasEncarceladas2.setText("No. de fichas encarceladas: " + (logicPlayers.get(Color.RED).numPawnsInHome()));
		player2.add(fichasEncarceladas2);
		player2.revalidate();
		
		playersInfo.removeAll();
		playersInfo.updateUI();
		playersInfo.repaint();
		playersInfo.add(player1);
		playersInfo.add(player2);
		playersInfo.revalidate();
	}
	
	
	private void prepareElementsMenu(){
        JMenuBar menu = new JMenuBar();
        JMenu archivo = new JMenu("Archivo");
        nuevo = new JMenuItem("Nuevo");
        abrir = new JMenuItem("Abrir");
        guardar = new JMenuItem("Salvar");
        salir = new JMenuItem("Salir");

        menu.add(archivo);
        archivo.add(nuevo);
        archivo.add(abrir);
        archivo.add(guardar);
        archivo.add(salir);

        setJMenuBar(menu);
    }
	

    private void prepareActions() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		rollTheDice.addActionListener(e -> actionRollDices());
		nuevo.addActionListener(e -> actionNew());
		abrir.addActionListener(e -> actionOpen());
		guardar.addActionListener(e -> actionSave());
		salir.addActionListener(e -> actionExit());
    }

	/**
	 * action responsible for displaying the dice in the window.
	 */
	private void actionRollDices() {
		ArrayList<Integer> values = new ArrayList<Integer>();
		Player currentPlayer = game.getCurrentPlayer();
		try {
			values = game.rollDice();
			newDice1.setValueDice(values.get(0));
			newDice2.setValueDice(values.get(1));
			newDice1.repaint();
			newDice2.repaint();
			refreshPawnOrder();
			refreshHouses();
			refreshInfo();
			refreshTable();

			if (game.getCurrentPlayer().getPawnsInGame() > 0 && (values.get(0) + values.get(1) != 5)){
				if (values.get(0) == 5 && values.get(1) != 5){
					//System.out.println(1);
					selectPawn(values.get(1));
				}else if (values.get(0) != 5 && values.get(1) == 5){
					//System.out.println(2);
					selectPawn(values.get(0));
				}else if (values.get(0) != 5 && values.get(1) != 5){
					//System.out.println(3);
					selectPawns(values);
				}
			}
		}catch (POOBChisException e){
			JOptionPane.showMessageDialog(null, e.getMessage());
		}

	}
	
	
	private void selectPawn(int dice){
		rollTheDice.setVisible(false);
		Color currentPlayer = game.getCurrentPlayer().getColor();
		JLabel message1 = new JLabel("Selecciona una ficha para moverla con el valor restante");
		
		JLabel message2 = new JLabel("Activar la habilidad de la ficha?");
		
		JButton confirm = new JButton("Confirmar");
		
		
		if (currentPlayer.equals(Color.YELLOW)){
			player1.removeAll();
			player1.updateUI();
			player1.repaint();
			
			player1.setLayout(new GridLayout(8,1));
			player1.add(message1);
			player1.add(pawn1);
			player1.add(pawn2);
			player1.add(pawn3);
			player1.add(pawn4);
			
			player1.add(message2);
			player1.add(yesSelection);
			
			player1.add(confirm);
		}else{
			player2.removeAll();
			player2.updateUI();
			player2.repaint();
			
			player2.setLayout(new GridLayout(8,1));
			player2.add(message1);
			player2.add(pawn1);
			player2.add(pawn2);
			player2.add(pawn3);
			player2.add(pawn4);
			
			player2.add(message2);
			player2.add(yesSelection);
			
			player2.add(confirm);
		}
		confirm.addActionListener(e -> actionPawnSelected(dice, 0));
	}
	
	
	private void actionPawnSelected(int usedDice, int waitingDice){
		Color colorPlayer = game.getCurrentPlayer().getColor();
		ArrayList<Integer> pawns = playersPawnsOrder.get(colorPlayer);
		Player currentPlayer = game.getCurrentPlayer();
		try{
			if (pawn1.isSelected()){
				if (yesSelection.isSelected()){
					game.activatePowerPawn(pawns.get(0));
				}else{
					game.play(pawns.get(0), usedDice);
				}
			}
			if(pawn2.isSelected()){
				if (yesSelection.isSelected()){
					game.activatePowerPawn(pawns.get(1));
				}else{
					game.play(pawns.get(1), usedDice);
				}
			}
			if(pawn3.isSelected()){
				if (yesSelection.isSelected()){
					game.activatePowerPawn(pawns.get(2));
				}else{
					game.play(pawns.get(2), usedDice);
				}
			}
			if(pawn4.isSelected()){
				if (yesSelection.isSelected()){
					game.activatePowerPawn(pawns.get(3));
				}else{
					game.play(pawns.get(3), usedDice);
				}
			}
			if (waitingDice == 0 || currentPlayer.getPawnsInGame() < 1){
				refreshTable();
				refreshPlayersInfo();
				refreshHouses();
				refreshInfo();
				rollTheDice.setVisible(true);
			}else{
				selectPawn(waitingDice);
			}
			
		}catch(POOBChisException e){
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}
	
	
	private void selectPawns(ArrayList <Integer> dices){
		rollTheDice.setVisible(false);
		Color currentPlayer = game.getCurrentPlayer().getColor();
		JLabel messg1 = new JLabel("Selecciona un valor del dado para la primera ficha");
		diceSelection1.setText("" + dices.get(0));
		diceSelection2.setText("" + dices.get(1));
		
		JLabel messg2 = new JLabel("Por favor, selecciona una ficha");
		
		JLabel messg3 = new JLabel("Activar la habilidad de la ficha?");
		
		JButton confirmar = new JButton("Confirmar");
		
		if (currentPlayer.equals(Color.YELLOW)){
			player1.removeAll();
			player1.updateUI();
			player1.repaint();
			player1.setLayout(new GridLayout(11,1));
			player1.add(messg1);
			player1.add(diceSelection1);
			player1.add(diceSelection2);
			
			player1.add(messg2);
			player1.add(pawn1);
			player1.add(pawn2);
			player1.add(pawn3);
			player1.add(pawn4);
			
			player1.add(messg3);
			player1.add(yesSelection);
			
			player1.add(confirmar);
		}else{
			player2.removeAll();
			player2.updateUI();
			player2.repaint();
			player2.setLayout(new GridLayout(11,1));
			player2.add(messg1);
			player2.add(diceSelection1);
			player2.add(diceSelection2);
			
			player2.add(messg2);
			player2.add(pawn1);
			player2.add(pawn2);
			player2.add(pawn3);
			player2.add(pawn4);
			
			player2.add(messg3);
			player2.add(yesSelection);
			
			player2.add(confirmar);
		}
		if (diceSelection1.isSelected()){
			int value1 = dices.get(0);
			int value2 = dices.get(1);
			confirmar.addActionListener(e -> actionPawnSelected(value1, value2));
		}else{
			int value1 = dices.get(1);
			int value2 = dices.get(0);
			confirmar.addActionListener(e -> actionPawnSelected(value1, value2));
		}
	}
	
	
	private void refreshInfo(){
		noParesEnPartida.setText("No. de pares obtenidos en el turno: " + (game.getCurrentPlayer().getEqualDiceNum()));
		if (game.getCurrentPlayer().getColor().equals(Color.RED)){
			turno.setText("Turno: Jugador Rojo");
		} else{
			turno.setText("Turno: Jugador Amarillo");
		}
	}
	
	
	private void refreshTable(){
		logicSquares = game.getGameBoard().getSquares();
		ArrayList<Pawn> actualPawns = new ArrayList<Pawn>();
		for (int i:squares.keySet()){
			if (squares.get(i).getNumPawnsSaved() != logicSquares.get(i).getNumPawns()){
				squares.get(i).removeAll();
				squares.get(i).updateUI();
				squares.get(i).repaint();
				if (logicSquares.get(i).getPawns().isEmpty()){
					squares.get(i).refresh(0, new ArrayList<Pawn>());
				}else{
					squares.get(i).refresh(logicSquares.get(i).getNumPawns(), logicSquares.get(i).getPawns());
				}

			}else{
				squares.get(i).setColor(logicSquares.get(i).getColor());
			}
		}
	}
	
	
	private void refreshHouses(){
		refreshDataHouses();
		for (Color c: logicHouses.keySet()){
			if (houses.get(c).getNumPawnsSaved() != logicHouses.get(c)){
				houses.get(c).removeAll();
				houses.get(c).updateUI();
				houses.get(c).repaint();
				if (logicHouses.get(c) == 0){
					houses.get(c).refresh(0, new ArrayList<Pawn>());
				}else{
					houses.get(c).refresh(logicHouses.get(c), logicPlayers.get(c).getPawnsInHome());
				}
			}
		}
	}
	
	private void refreshPawnOrder(){
		Player currentPlayer = game.getCurrentPlayer();
		ArrayList<Integer> order = new ArrayList<Integer>();
		ArrayList<Pawn> pawnList = currentPlayer.getPawns();
		boolean flag = true;
		int maxPawn = 0;
		while(flag){
			maxPawn = getMax(pawnList);
			for (Pawn p: pawnList){
				if (p.getSquaresToHome() == maxPawn){
					order.add(p.getNumber());
					pawnList.remove(p);
					break;
				}
			}
			if (pawnList.isEmpty()){
				flag = false;
			}
		}
		playersPawnsOrder.put(currentPlayer.getColor(), order);
	}
	
	
	private int getMax(ArrayList<Pawn> pawns){
		int maxPawn = pawns.get(0).getSquaresToHome();
		for (Pawn p: pawns){
			if (p.getSquaresToHome() < maxPawn){
				maxPawn = p.getSquaresToHome();
			}
		}
		return maxPawn;
	}
	
	
	private void refresh(){
		refreshTable();
		refreshPlayersInfo();
		refreshHouses();
		refreshDataHouses();
		refreshPawnOrder();
		refreshInfo();
	}
	
	
	private void actionNew(){
         game = new POOBChisGame(2);
		 this.revalidate();
         this.repaint();
		rollTheDice.setVisible(true);
		 refresh();
    }
	
	
	private void actionOpen(){
        try{
            JFileChooser fileChooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter( ".dat","dat");
            fileChooser.setDialogTitle("Abrir");
            fileChooser.setFileFilter(filter);
            int selection = fileChooser.showSaveDialog(this);
            if (selection == JFileChooser.APPROVE_OPTION) {
                POOBChisGame newGame = game.open(fileChooser.getSelectedFile());
                this.game = newGame;
				this.revalidate();
                this.repaint();
				this.refresh();
            }
        }catch (POOBChisException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }


    private void actionSave(){
        try{
            JFileChooser fileChooser = new JFileChooser();
            FileNameExtensionFilter filter = new FileNameExtensionFilter( ".dat","dat");
            fileChooser.setDialogTitle("Guardar");
            fileChooser.setFileFilter(filter);
            int selection = fileChooser.showSaveDialog(this);
            if (selection == JFileChooser.APPROVE_OPTION) {
                game.save(fileChooser.getSelectedFile());
            }
        }catch (POOBChisException e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
	
	
	private void actionExit(){
        int valor = JOptionPane.showConfirmDialog(this, "Exit game?", "Warning", JOptionPane.YES_NO_OPTION);
        if (valor == JOptionPane.YES_OPTION){
            System.exit(0);
        }
    }
	
	
    public static void main(String args[]){
		if(solitario == null){
			POOBChisGUI gui = new POOBChisGUI();
			solitario = gui;
			gui.setVisible(true);
		}


    }

}
