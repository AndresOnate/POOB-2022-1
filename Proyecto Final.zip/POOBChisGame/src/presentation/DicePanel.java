package presentation;

import javax.swing.*;
import java.awt.*;

public class DicePanel extends JPanel{
    private int valueDice = 1;

    /**
     * Method that allows changing the value associated with the board panel.
     * @param number new dice number
     */
    public void setValueDice(int number){
        this.valueDice = number;
    }

    @Override
    public void paint(Graphics g){
        ImageIcon back = new ImageIcon(getClass().getResource("/images/"+ valueDice+".PNG"));
        g.drawImage(back.getImage(),0,0,getWidth(),getHeight(),this);
        setOpaque(false);
        super.paint(g);
    }
}
