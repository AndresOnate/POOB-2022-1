package presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class PawnGraphic extends JPanel {

    private JPanel casillaPropia;
    private String miTipoCasilla;
	private Color myColor;
	private Color myAbility = Color.WHITE;

    public PawnGraphic(JPanel square, String type, Color newColor){
        this.casillaPropia = square;
		this.miTipoCasilla = type;
		this.myColor = newColor;
    }
	
	
	public PawnGraphic(JPanel square, String type, Color newColor, Color ability){
        this.casillaPropia = square;
		this.miTipoCasilla = type;
		this.myColor = newColor;
		this.myAbility = ability;
    }

    public void paintComponent (Graphics g) {
		Graphics2D graphic = (Graphics2D) g;
		super.paintComponent(g);
		if (miTipoCasilla != "House"){
			int x = 24;
			int y = 24;
			int dx = x / 4;
			int dy = y / 4;
			graphic.fillOval(dx - 3, dy - 3, x + 1, x + 1);
			graphic.drawOval(dx + 1, dy + 1, x - 8, x - 8);
			graphic.setPaint(this.myColor);
			graphic.fillOval(dx - 3, dy - 3, x - 1, x - 1);
			graphic.setPaint(Color.WHITE);
			graphic.fillOval(dx + 1, dy + 1, x - 8, x - 8);
			graphic.setPaint(Color.BLACK);
			graphic.drawOval(dx + 1, dy + 1, x - 8, x - 8);
			graphic.setPaint(this.myAbility);
			graphic.fillOval(dx + 5, dy + 5, x - 16, x - 16);
		} else{
			int x = 60;
			int y = 60;
			int dx = x / 2;
			int dy = y / 2;
			graphic.fillOval(dx - 4, dy - 4, x + 5, x + 5);
			graphic.drawOval(dx - 3, dy - 3, x - 1, x - 1);
			graphic.setPaint(this.myColor);
			graphic.fillOval(dx - 3, dy - 3, x - 1, x - 1);
			graphic.setPaint(Color.WHITE);
			graphic.fillOval(dx + 5, dy + 5, x - 16, x - 16);
			graphic.setPaint(Color.BLACK);
			graphic.drawOval(dx + 5, dy + 5, x - 16, x - 16);
			graphic.setPaint(this.myAbility);
			graphic.fillOval(dx + 13, dy + 13, x - 32, x - 32);
		}
    }
}
