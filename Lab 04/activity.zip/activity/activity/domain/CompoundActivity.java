package domain;
import java.util.ArrayList;

public class CompoundActivity extends Activity{
    private ArrayList<Activity> activities;
    
    public CompoundActivity(String code, String name){
        super(code,name);
        activities= new ArrayList<Activity>();
    }
    
    public void addActivity(Activity a){
        activities.add(a);
    }
    
    @Override
    public int credits() throws ActivityException{
        return 0;
    }
    
    
}
