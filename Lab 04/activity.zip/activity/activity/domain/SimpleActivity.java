package domain;

public class SimpleActivity extends Activity{
    private Integer credits;
    private String learningResults;
    
    public SimpleActivity(String code, String name,Integer credits){
        super(code,name);
        this.credits=credits;
    }
    
    public SimpleActivity(String code, String name, String learningResults, Integer credits){
        super(code,name);
        this.learningResults=learningResults;
        this.credits=credits;
        
    }
    
    @Override
    public String results(){
        return learningResults;
    }
    
    @Override
    public int credits() throws ActivityException{
        return 0;
    }

}
