package domain;

public abstract class Activity{
    private String code;
    private String name;
    
    public Activity(String code, String name){
        this.code=code;
        this.name=name;
    }
    
    public String getCode(){
        return code;
    }
    
    public String getName(){
        return name;
    }
    
    public String results(){
        return "";
    }
        
    public abstract int credits() throws ActivityException;
    
    /**Calculate the number of credits conscodeering the well-defined activities
     * @return 
     * */
    //public abstract int definedCredits();
    

    //public abstract int credits(String name) throws ActivityException;

    
}
